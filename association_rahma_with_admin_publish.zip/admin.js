const $=id=>document.getElementById(id);
let client=null;
function status(message,isError=false){$('status').textContent=message;$('status').className=isError?'error':'muted';}
function escapeHTML(value=''){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function configured(){
  return window.supabase && window.RAHMA_SUPABASE_URL && !window.RAHMA_SUPABASE_URL.startsWith('YOUR_') && window.RAHMA_SUPABASE_ANON_KEY && !window.RAHMA_SUPABASE_ANON_KEY.startsWith('YOUR_');
}
function showSession(session){
  $('login-panel').hidden=!!session;
  $('dashboard').hidden=!session;
  if(session) refreshPosts();
}
async function refreshPosts(){
  const box=$('admin-posts');box.innerHTML='<p class="muted">جارٍ التحميل...</p>';
  const {data,error}=await client.from('posts').select('*').order('created_at',{ascending:false});
  if(error){box.textContent='تعذر تحميل المنشورات: '+error.message;return;}
  if(!data.length){box.innerHTML='<p class="muted">لا توجد منشورات بعد.</p>';return;}
  box.innerHTML=data.map(p=>`<article class="admin-post"><div><strong>${escapeHTML(p.title)}</strong><p>${escapeHTML(p.content)}</p></div><div class="post-actions"><button class="outline" data-edit="${p.id}">تعديل</button><button class="danger" data-delete="${p.id}">حذف</button></div></article>`).join('');
  box.querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',()=>editPost(data.find(p=>p.id===b.dataset.edit))));
  box.querySelectorAll('[data-delete]').forEach(b=>b.addEventListener('click',()=>deletePost(b.dataset.delete)));
}
function editPost(p){
  $('post-id').value=p.id;$('post-title').value=p.title;$('post-content').value=p.content;$('post-image').value=p.image_url||'';
  $('save-post').textContent='حفظ التعديلات';$('cancel-edit').hidden=false;window.scrollTo({top:0,behavior:'smooth'});
}
function resetForm(){
  $('post-form').reset();$('post-id').value='';$('save-post').textContent='نشر المنشور';$('cancel-edit').hidden=true;
}
async function deletePost(id){
  if(!confirm('هل تريد حذف هذا المنشور نهائياً؟'))return;
  const {error}=await client.from('posts').delete().eq('id',id);
  if(error){status('فشل الحذف: '+error.message,true);return;}
  status('تم حذف المنشور.');refreshPosts();
}
if(!configured()){
  $('login-panel').innerHTML='<h2>الإعداد الأولي مطلوب</h2><p>أضف رابط مشروع Supabase ومفتاح anon إلى ملف config.js، ثم نفّذ تعليمات README-ADMIN.txt لإنشاء قاعدة البيانات وحساب المسؤول.</p>';
}else{
  client=window.supabase.createClient(window.RAHMA_SUPABASE_URL,window.RAHMA_SUPABASE_ANON_KEY);
  client.auth.getSession().then(({data})=>showSession(data.session));
  client.auth.onAuthStateChange((_event,session)=>showSession(session));
}
$('login-form').addEventListener('submit',async e=>{
  e.preventDefault();if(!client)return;
  const {error}=await client.auth.signInWithPassword({email:$('email').value,password:$('password').value});
  if(error)alert('تعذر تسجيل الدخول: '+error.message);
});
$('logout').addEventListener('click',async()=>{if(client)await client.auth.signOut();});
$('cancel-edit').addEventListener('click',resetForm);
$('post-form').addEventListener('submit',async e=>{
  e.preventDefault();if(!client)return;
  const id=$('post-id').value;
  const payload={title:$('post-title').value.trim(),content:$('post-content').value.trim(),image_url:$('post-image').value.trim()||null};
  const result=id?await client.from('posts').update(payload).eq('id',id):await client.from('posts').insert(payload);
  if(result.error){status('تعذر حفظ المنشور: '+result.error.message,true);return;}
  status(id?'تم تحديث المنشور بنجاح.':'تم نشر المنشور بنجاح.');
  resetForm();refreshPosts();
});
