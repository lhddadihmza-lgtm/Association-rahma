// ضع بيانات مشروع Supabase هنا بعد إنشائه. لا تضع كلمة مرور المسؤول في هذا الملف.
window.RAHMA_SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
window.RAHMA_SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
