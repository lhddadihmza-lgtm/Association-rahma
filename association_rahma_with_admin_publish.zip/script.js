const btn=document.getElementById('lang');
let lang='ar';
btn.addEventListener('click',()=>{
  lang=lang==='ar'?'fr':'ar';
  document.documentElement.lang=lang;
  document.documentElement.dir=lang==='ar'?'rtl':'ltr';
  document.querySelectorAll('[data-ar]').forEach(el=>el.textContent=el.dataset[lang]);
  btn.textContent=lang==='ar'?'Français':'العربية';
});
document.getElementById('year').textContent=new Date().getFullYear();

function escapeHTML(value='') {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
async function loadPosts() {
  const box=document.getElementById('posts-list');
  if (!window.supabase || !window.RAHMA_SUPABASE_URL || window.RAHMA_SUPABASE_URL.startsWith('YOUR_')) {
    box.innerHTML='<p class="muted">سيتم عرض منشورات الجمعية هنا بعد إعداد خدمة النشر.</p>';
    return;
  }
  try {
    const client=window.supabase.createClient(window.RAHMA_SUPABASE_URL,window.RAHMA_SUPABASE_ANON_KEY);
    const {data,error}=await client.from('posts').select('*').order('created_at',{ascending:false});
    if(error) throw error;
    if(!data.length){box.innerHTML='<p class="muted">لا توجد منشورات حالياً.</p>';return;}
    box.innerHTML=data.map(post=>`<article class="card post-card">
      ${post.image_url ? `<img class="post-image" src="${escapeHTML(post.image_url)}" alt="">` : ''}
      <h3>${escapeHTML(post.title)}</h3><p>${escapeHTML(post.content).replace(/\n/g,'<br>')}</p>
      <small class="muted">${new Date(post.created_at).toLocaleDateString('ar-MA')}</small>
    </article>`).join('');
  } catch(err) {
    box.innerHTML='<p class="muted">تعذر تحميل المنشورات. تحقق من إعدادات النشر والاتصال.</p>';
    console.error(err);
  }
}
loadPosts();
