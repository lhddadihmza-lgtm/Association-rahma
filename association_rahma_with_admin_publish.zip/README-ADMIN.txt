إضافة نظام النشر للمسؤول - جمعية الرحمة
========================================

مهم: الموقع ثابت (HTML) ولذلك يحتاج إلى قاعدة بيانات وخدمة تسجيل دخول حتى تظهر المنشورات لجميع الزوار بشكل آمن. أُعدّ هذا الإصدار للعمل مع Supabase.

1) إنشاء مشروع Supabase
- افتح https://supabase.com وأنشئ مشروعاً جديداً.
- من Project Settings > API انسخ Project URL و anon/public key.
- افتح config.js وضع القيم مكان YOUR_SUPABASE_PROJECT_URL و YOUR_SUPABASE_ANON_KEY.
- لا تضع كلمة مرور المسؤول أو service_role key في ملفات الموقع.

2) إنشاء جدول المنشورات
افتح SQL Editor في Supabase والصق الأمر التالي. قبل التنفيذ استبدل ADMIN_USER_UUID بمعرّف المستخدم الخاص بالمسؤول (UUID) بعد إنشائه في الخطوة 3.

create table public.posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text not null,
  image_url text,
  created_at timestamptz not null default now()
);

alter table public.posts enable row level security;

create policy "Public can read posts"
on public.posts for select
to anon, authenticated
using (true);

create policy "Only designated admin can insert"
on public.posts for insert
to authenticated
with check (auth.uid() = 'ADMIN_USER_UUID'::uuid);

create policy "Only designated admin can update"
on public.posts for update
to authenticated
using (auth.uid() = 'ADMIN_USER_UUID'::uuid)
with check (auth.uid() = 'ADMIN_USER_UUID'::uuid);

create policy "Only designated admin can delete"
on public.posts for delete
to authenticated
using (auth.uid() = 'ADMIN_USER_UUID'::uuid);

3) إنشاء حساب المسؤول
- من Authentication > Users أنشئ/ادعُ حساباً بالبريد الإلكتروني المخصص للمسؤول.
- انسخ User UID لذلك الحساب.
- استبدل ADMIN_USER_UUID في سياسات SQL أعلاه بمعرّف UID الحقيقي ثم نفّذ SQL.
- عطّل التسجيل العام (Allow new users to sign up) من إعدادات Authentication حتى لا ينشئ الزوار حسابات.
- احتفظ بكلمة مرور المسؤول في مكان آمن ولا تشاركها.

ملاحظة: إذا أنشأت الجدول والسياسات أولاً، أعد تنفيذ سياسات RLS بعد وضع UID الحقيقي. لا تترك النص ADMIN_USER_UUID كما هو.

4) رفع الموقع
ارفع جميع الملفات والمجلدات الموجودة في هذا المجلد إلى استضافتك (GitHub Pages أو Netlify). يجب أن يكون admin.html و config.js و admin.js في نفس مستوى index.html.

5) الاستخدام
- افتح صفحة الموقع ثم اضغط «دخول المسؤول».
- سجّل الدخول بالبريد وكلمة المرور اللذين أنشأتهما.
- أضف عنوان المنشور ومحتواه ورابط صورة عام (اختياري)، ثم اضغط «نشر المنشور».
- ستظهر المنشورات في قسم «آخر المستجدات والإعلانات» للزوار.
- يمكنك تعديل أي منشور أو حذفه من لوحة المسؤول.

تنبيه حول الصور:
حقل الصورة يقبل رابط صورة متاحاً للعامة يبدأ بـ https:// . هذا الإصدار لا يرفع ملفات الصور مباشرة إلى التخزين؛ يمكن إضافة خدمة رفع الصور لاحقاً.

قبل النشر النهائي:
- أدخل بيانات Supabase في config.js.
- أنشئ حساب مسؤول واحداً فقط، وأوقف التسجيل العام.
- اختبر تسجيل الدخول والنشر والحذف من الموقع المستضاف عبر HTTPS.
